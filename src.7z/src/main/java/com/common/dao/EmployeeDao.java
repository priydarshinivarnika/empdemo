package com.common.dao;

import java.util.List;
import com.common.model.EmployeeData;

public interface EmployeeDao {

	public List<EmployeeData> list();

}
