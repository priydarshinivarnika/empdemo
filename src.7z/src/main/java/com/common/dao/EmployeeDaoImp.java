package com.common.dao;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;

import com.common.model.EmployeeData;

public class EmployeeDaoImp implements EmployeeDao {

	private SessionFactory sessionFactory;
	
	public EmployeeDaoImp(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }



	    //@Transactional
	    public List<EmployeeData> list() {
	        @SuppressWarnings("unchecked")
	        List<EmployeeData> listUser = (List<EmployeeData>) sessionFactory.getCurrentSession()
	                .createCriteria(EmployeeData.class)
	                .setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
	 
	        return listUser;
	    }
	 


	
}
