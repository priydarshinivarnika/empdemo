package com.common.model;

import java.util.Set;

public class SkillData {

	private int skillId;
	private String skillName;

	private Set<EmployeeData> employeeData;

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public Set<EmployeeData> getEmployeeData() {
		return employeeData;
	}

	public void setEmployeeData(Set<EmployeeData> employeeData) {
		this.employeeData = employeeData;
	}

}
