package com.common.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StoreData {
	public static void main(String[] args) {

		// creating configuration object
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");// populates the data of the configuration file
		SessionFactory factory = cfg.buildSessionFactory();// creating session factory object

		Session session = factory.openSession();// creating session object
		Transaction t = session.beginTransaction();// creating transaction object

		EmployeeData e1 = new EmployeeData();
		
		e1.setEmpFirstName("First");
		e1.setEmpLastName("Name");
		e1.setEmpDepartment("Development");

		EmployeeData e2 = new EmployeeData();
		e2.setEmpFirstName("Second");
		e2.setEmpLastName("Name");
		e2.setEmpDepartment("Support");

		EmployeeData e3 = new EmployeeData();
		e3.setEmpFirstName("Third");
		e3.setEmpLastName("Name");
		e3.setEmpDepartment("Management");

		session.persist(e1);// persisting the object
		session.persist(e2);// persisting the object
		session.persist(e3);// persisting the object

		SkillData s1 = new SkillData();
		s1.setSkillName("Excel");
		session.persist(s1);

		SkillData s2 = new SkillData();
		s2.setSkillName("Java");
		session.persist(s2);

		t.commit();// transaction is committed
		session.close();
		System.out.println("successfully saved the emp and skill table with new records.");
		
		// ONE emp to MANY skill
		List<SkillData> skills = new ArrayList<SkillData>();
		skills.add(s1);
		skills.add(s2);
		
		addSkillsForEmployee(skills, e1, factory.openSession());
		addSkillsForEmployee(skills, e2, factory.openSession());

		List<EmployeesSkill> empskills = getAllSkillsForEmployee(e2, factory.openSession());
		System.out.println(empskills);
		
		List<Integer> emp_skill = new ArrayList<Integer>();
		
		
		for (EmployeesSkill skill : empskills) {
			System.out.println("Emp id :" + skill.getEmpId() + " has skill : " + skill.getSkillId());
			emp_skill.add(skill.getSkillId());

		}
		
		List<SkillData> s = new ArrayList<SkillData>();
	}

	public static List<EmployeesSkill> getAllSkillsForEmployee(EmployeeData employee, Session session) {
		List<EmployeesSkill> skills = new ArrayList<EmployeesSkill>();
		int empid = employee.getEmpId();
		Query query = session.createQuery("from EmployeesSkill a where a.empId=:empid ");
		query.setParameter("empid", empid);
		skills = query.list();
		return skills;
	}

	public static void addSkillsForEmployee(List<SkillData> skills, EmployeeData employee, Session session) {

		for (SkillData skill : skills) {
			EmployeesSkill empskill = new EmployeesSkill();
			Transaction t = session.beginTransaction();
			empskill.setEmpId(employee.getEmpId());
			empskill.setSkillId(skill.getSkillId());
			session.persist(empskill);
			t.commit();
		}
		session.close();
		System.out.println("employee skill successfully saved");

	}
	public static List<SkillData> getAllSkillById(List<Integer> skillIdList, Session session) {
		List<SkillData> skills = new ArrayList<SkillData>();
		for (SkillData skill : skills) {
			Query query = session.createQuery("from SkillData a where a.skillId=:id ");
			query.setParameter("id", skill.getSkillId());
		}
		return skills;
	}

}
