package com.common.model;

import java.util.Set;

public class EmployeeData {

	private int empId;
	private String empFirstName, empLastName, empDepartment;

	private Set<SkillData> skillData;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public String getEmpDepartment() {
		return empDepartment;
	}

	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}

	public Set<SkillData> getSkillData() {
		return skillData;
	}

	public void setSkillData(Set<SkillData> skillData) {
		this.skillData = skillData;
	}

}
