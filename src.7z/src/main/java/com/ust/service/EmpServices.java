package com.ust.service;

import java.util.List;
import com.ust.model.Employee;

public interface EmpServices {

	 Employee findById(long id);
     
	 Employee findByName(String name);
	     
	    void saveEmployee(Employee emp);
	     
	    void updateEmployee(Employee emp);
	     
	    void deleteEmployeeById(long id);
	 
	    List<Employee> findAllEmployees(); 
	     
	    void deleteAllEmployees();
	     
	    public boolean isEmployeeExist(Employee emp);

}
