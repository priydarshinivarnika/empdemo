package com.ust.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Service;

import com.ust.model.Employee;
import com.ust.model.HibernateUtil;
import com.ust.model.Skill;

@Service("empService")
public class EmployeeServiceImpl {

	private static List<Employee> emps = new ArrayList<Employee>(10);

	static {

		System.out.println("Hibernate Many to Many (XML mapping)");
		emps = populateDummyEmployees();
	}

	public static List<Employee> populateDummyEmployees() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		for (int i = 1; i <= 10; i++) {
			Employee emp = new Employee();
			emp.setFirstName("First" + i);
			emp.setLastName("Name");
			emp.setDepartment("Development");
			emp.getSkillDatas().add(new Skill("Java"));
			emp.getSkillDatas().add(new Skill("Sql"));
			session.persist(emp);
		}
		session.getTransaction().commit();
		System.out.println("successfully saved all the table");

		session.close();
		HibernateUtil.getSessionFactory().close();
		return emps;
	}
	 public List<Employee> findAllEmployees() {
	        return emps;
	    }


}
