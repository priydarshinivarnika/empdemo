package com.ust.config;

import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.web.client.RestTemplate;

import com.ust.controller.EmpUriConstants;
import com.ust.model.EmployeeEntity;

//import com.common.controller.EmpUriConstants;


public class TestSpringRest {
	public static final String SERVER_URI = "http://localhost:8082/SpringMVC/rest/kfc/brands";

	public static void main(String args[]) {

		//testGetDummyEmployee();
		System.out.println("*****");
		//testCreateEmployee();
		System.out.println("*****");
		// testGetEmployee();
		System.out.println("*****");
		//testGetAllEmployee();
	}

	private static void testGetDummyEmployee() {
		RestTemplate restTemplate = new RestTemplate();
		EmployeeEntity emp = restTemplate.getForObject(SERVER_URI + EmpUriConstants.DUMMY_EMP, EmployeeEntity.class);
		printEmpData(emp);
	}

	private static void testCreateEmployee() {
		RestTemplate restTemplate = new RestTemplate();
		EmployeeEntity emp = new EmployeeEntity();
		emp.setEmployeeId(4);
		emp.setFirstName("Dipesh");
		emp.setLastName("Name");
		emp.setEmail("Hadoop");
		emp.setDepartment("Dev");
		EmployeeEntity response = restTemplate.postForObject(SERVER_URI + EmpUriConstants.CREATE_EMP, emp, EmployeeEntity.class);
		printEmpData(response);
	}

	private static void testGetEmployee() {
		RestTemplate restTemplate = new RestTemplate();
		EmployeeEntity emp = restTemplate.getForObject(SERVER_URI + "/rest/emp/1", EmployeeEntity.class);
		printEmpData(emp);
	}

	private static void testGetAllEmployee() {
		RestTemplate restTemplate = new RestTemplate();
		List<LinkedHashMap> emps = restTemplate.getForObject(SERVER_URI + EmpUriConstants.GET_ALL_EMP, List.class);
		System.out.println(emps.size());
		for (LinkedHashMap map : emps) {
			System.out.println(
					"ID=" + map.get("empId") + ",Name=" + map.get("empName") + ", Skill=" + map.get("empSkill"));
			;
		}
	}

	public static void printEmpData(EmployeeEntity emp) {
		System.out.println("ID=" + emp.getEmployeeId() + ",First_Name=" + emp.getFirstName() + ",Last_Name=" + emp.getLastName() + ", Department=" + emp.getDepartment()+ ", Email=" + emp.getEmail());
	}

}
