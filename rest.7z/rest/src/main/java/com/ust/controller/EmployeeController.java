package com.ust.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import org.springframework.web.bind.annotation.RestController;

import com.ust.model.EmployeeEntity;

@Controller
@RequestMapping("/details")
public class EmployeeController {

	
	// Map to store details of employees
	Map<Integer, EmployeeEntity> empData = new HashMap<Integer, EmployeeEntity>();

	
	@RequestMapping(value = EmpUriConstants.DUMMY_EMP, method = RequestMethod.GET)
	public @ResponseBody EmployeeEntity getDummyEmployee() {

		EmployeeEntity emp = new EmployeeEntity();
		emp.setEmployeeId(1);
		emp.setEmail("xyz@ust.com");
		emp.setFirstName("Varnika");
		emp.setLastName("Priydarshini");
		emp.setDepartment("Dev");
		empData.put(1, emp);
		return emp;
	}

	@RequestMapping(value = EmpUriConstants.CREATE_EMP, method = RequestMethod.POST)
	public @ResponseBody EmployeeEntity createEmployee(@RequestBody EmployeeEntity emp) {

		empData.put(emp.getEmployeeId(), emp);
		return emp;
	}
	@RequestMapping(value = EmpUriConstants.GET_EMP, method = RequestMethod.GET)
	public @ResponseBody EmployeeEntity getEmployee(@PathVariable("id") int empId) {

		return empData.get(empId);

	}

	@RequestMapping(value = EmpUriConstants.GET_ALL_EMP, method = RequestMethod.GET)
	public @ResponseBody List<EmployeeEntity> getAllEmployees() {

		List<EmployeeEntity> emps = new ArrayList<EmployeeEntity>();
		Set<Integer> empIdKeys = empData.keySet();
		for (Integer i : empIdKeys) {
			emps.add(empData.get(i));
		}
		return emps;
	}

	@RequestMapping(value = EmpUriConstants.UPDATE_EMP, method = RequestMethod.PUT)
	public @ResponseBody EmployeeEntity updateEmployee(@PathVariable("id") int empId) {

		EmployeeEntity emp = empData.get(empId);
		empData.remove(empId);
		return emp;
	}

	@RequestMapping(value = EmpUriConstants.DELETE_EMP, method = RequestMethod.PUT)
	public @ResponseBody EmployeeEntity deleteEmployee(@PathVariable("id") int empId) {

		EmployeeEntity emp = empData.get(empId);
		empData.remove(empId);
		return emp;
	}

}