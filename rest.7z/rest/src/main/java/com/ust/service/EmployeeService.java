package com.ust.service;

import java.util.List;

import com.ust.dao.EmployeeDaoImp;

public interface EmployeeService {

	long save(EmployeeServiceImp emp);

	EmployeeServiceImp get(long id);

	List<EmployeeServiceImp> list();

	void update(long id, EmployeeServiceImp emp);

	void delete(long id);
}
