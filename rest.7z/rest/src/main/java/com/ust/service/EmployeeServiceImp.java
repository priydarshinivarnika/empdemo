package com.ust.service;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import com.ust.dao.EmployeeDao;

	@Service
	@Transactional(readOnly = true)
	public class EmployeeServiceImp implements EmployeeService {
	   @Autowired
	   private EmployeeDao empDao;

	   @Transactional
	   @Override
	   public long save(EmployeeServiceImp emp) {
	      return empDao.save(emp);
	   }

	   @Override
	   public EmployeeServiceImp get(long id) {
	      return empDao.get(id);	
	   }

	   @Override
	   public List<EmployeeServiceImp> list() {
	      return empDao.list();
	   }

	   @Transactional
	   @Override
	   public void update(long id, EmployeeServiceImp emp) {
	      empDao.update(id, emp);
	   }

	   @Transactional
	   @Override
	   public void delete(long id) {
	      empDao.delete(id);
	   }
	}

