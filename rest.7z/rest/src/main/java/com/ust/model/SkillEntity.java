package com.ust.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity(name = "JoinTableSkillEntity")
@Table(name = "SKILL", uniqueConstraints = { @UniqueConstraint(columnNames = "ID") })
public class SkillEntity implements Serializable, SkillService {

	private static final long serialVersionUID = -6790693372846798580L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer skillId;

	@Column(name = "NAME", unique = false, nullable = false, length = 100)
	private String name;

	/*
	 * @OneToMany(cascade = CascadeType.ALL)
	 * 
	 * @JoinTable(name = "EMPLOYEE_SKILL", joinColumns = {
	 * 
	 * @JoinColumn(name = "SKILL_ID", referencedColumnName = "ID") },
	 * inverseJoinColumns = {
	 * 
	 * @JoinColumn(name = "EMPLOYEE_ID", referencedColumnName = "ID") }) private
	 * Set<EmployeeEntity> employees;
	 */
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EMPLOYEE_ID", nullable = true)
	private EmployeeEntity emps;

	public SkillEntity() {
	}

	public SkillEntity(String name, EmployeeEntity emp) {
		this.name = name;
		this.emps = emp;
	}

	public Integer getSkillId() {
		return skillId;
	}

	public void setSkillId(Integer skillId) {
		this.skillId = skillId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public EmployeeEntity getEmps() {
		return emps;
	}

	public void setEmps(EmployeeEntity emps) {
		this.emps = emps;
	}

	/*
	 * public Set<EmployeeEntity> getEmployees() { return employees; }
	 * 
	 * public void setEmployees(Set<EmployeeEntity> employees) { this.employees
	 * = employees; }
	 */
	@Override
	public String toString() {
		return "SkillEntity [skillId=" + skillId + ", name=" + name + " ]";
	}

	/*
	 * public void addEmployee(EmployeeEntity emp) { if (emp == null) throw new
	 * IllegalArgumentException("Null employee"); emp.getSkills().add(this);
	 * employee.add(emp); }
	 */

}
