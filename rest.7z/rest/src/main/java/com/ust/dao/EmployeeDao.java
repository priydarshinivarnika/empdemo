package com.ust.dao;

import java.util.List;

import com.ust.service.EmployeeServiceImp;


public interface EmployeeDao {

	long save(EmployeeServiceImp emp);

	EmployeeServiceImp get(long id);

	List<EmployeeServiceImp> list();

	void update(long id, EmployeeServiceImp emp);

	void delete(long id);

}
