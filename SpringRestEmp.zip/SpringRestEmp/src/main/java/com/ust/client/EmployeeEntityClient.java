package com.ust.client;

public class EmployeeEntityClient {

}
