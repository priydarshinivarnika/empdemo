package com.ust.repository;

import java.util.List;

import com.ust.model.EmployeeEntity;

public interface EmployeeRepository {

	List<EmployeeEntity> populateDummyEmployees();

	List<EmployeeEntity> findAllEmployees();

	EmployeeEntity findById(Integer employeeID);

	EmployeeEntity findByFirstName(String firstName);

	List<EmployeeEntity> createNewEmployee(EmployeeEntity emp);

	void deleteEmployeeById(Integer employeeID);

	void deleteAllEmployees();

	EmployeeEntity modifyEmployee(Integer employeeID);
	
	//void modifyEmployee(EmployeeEntity emp);

}
