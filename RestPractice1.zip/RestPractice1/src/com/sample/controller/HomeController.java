package com.sample.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sample.model.User;
import com.sample.services.IUserServices;

@Controller
public class HomeController {

	@Autowired
	private IUserServices userServices;

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		System.out.println("Home Page Requested, locale = " + locale);
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG,
				DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "home";
	}

	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public String user(@Validated User user, Model model) {
		System.out.println("User Page Requested");

		model.addAttribute("userName", user.getUserName());
		return "user";
	}

	@RequestMapping(value = "/user/logout", method = RequestMethod.POST)
	public String logout() {
		System.out.println("Logout Page Requested");
		return "logout";
	}

	@RequestMapping(value = "/user/register", method = RequestMethod.GET)
	public String register() {
		System.out.println("Register Page Requested - GET");
		return "register";
	}

	@RequestMapping(value = "/user/register", method = RequestMethod.POST)
	public String register(@Validated User user, Model model) {
		System.out.println("Register Page Requested - POST");
		userServices.saveUser(user);
		model.addAttribute("userName", user.getUserName());
		return "user";
	}
}