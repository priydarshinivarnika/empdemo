package com.ServletProject.operation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String message;
	private String directoryName = "C:/Users/vxp142/DataInFileFormat";
	private String fileName = "servletData";

	public void init() {

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");

		if (username.isEmpty() || password.isEmpty()) {

			RequestDispatcher req = request.getRequestDispatcher("index.jsp");
			req.include(request, response);
		}

		else if (username.equals("admin") && password.equals("admin")) {
			RequestDispatcher req = request.getRequestDispatcher("signIn.jsp");
			req.include(request, response);

		} else {

			File file = new File(directoryName + "/" + fileName);

			String line = null;

			try {

				FileReader fileReader = new FileReader(file);
				boolean isMatch = false;
				BufferedReader bufferedReader = new BufferedReader(fileReader);

				while ((line = bufferedReader.readLine()) != null) {

					String[] userProfile = line.split(",");
					
					if (userProfile[2].equals(username)
							&& userProfile[3].equals(password)) {
						message = "Welcome\t" + username;
						RequestDispatcher req = request
								.getRequestDispatcher("signIn.jsp");
						req.include(request, response);
						isMatch = true;
						break;

					}
					
				}
				bufferedReader.close();
				
				if (!isMatch) {
					RequestDispatcher req = request
							.getRequestDispatcher("error.jsp");
					req.include(request, response);
				}


			} catch (FileNotFoundException ex) {
				System.out.println("<h1>Unable to open file " + fileName
						+ "</h1>");
			} catch (IOException ex) {
				System.out.println("<h1>Error reading file " + fileName
						+ "</h1>");
			}
		}
	}
}
