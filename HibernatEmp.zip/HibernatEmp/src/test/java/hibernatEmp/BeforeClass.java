package hibernatEmp;

public @interface BeforeClass {

}
