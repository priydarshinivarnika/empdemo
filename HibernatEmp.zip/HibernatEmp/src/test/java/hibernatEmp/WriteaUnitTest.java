package hibernatEmp;

public class WriteaUnitTest {

}
